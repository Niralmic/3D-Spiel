
extends CharacterBody3D

@export var walk_speed: float = 5.0
@export var sprint_speed: float = 9.0
@export var jump_velocity: float = 5.5
@export var mouse_sensitivity: float = 0.002

var gravity = ProjectSettings.get_setting(
    "physics/3d/default_gravity"
)

@onready var camera_pivot = $"Camera Pivot"

func _ready():
	Input.mouse_mode = Input.MOUSE_MODE_CAPTURED

func _unhandled_input(event):
	if event is InputEventMouseMotion:
		camera_pivot.rotate_y(
			-event.relative.x * mouse_sensitivity
		)
		camera_pivot.rotate_x(
			-event.relative.y * mouse_sensitivity
		)

		camera_pivot.rotation.x = clamp(
			camera_pivot.rotation.x,
			deg_to_rad(-80),
			deg_to_rad(80)
		)

	if event.is_action_pressed("ui_cancel"):
		Input.mouse_mode = Input.MOUSE_MODE_VISIBLE

func _physics_process(delta):
	# Schwerkraft
	if not is_on_floor():
		velocity.y -= gravity * delta

	# Springen
	if Input.is_action_just_pressed("jump") and is_on_floor():
		velocity.y = jump_velocity

	# Bewegung
	var input_dir = Input.get_vector(
		"move_left",
		"move_right",
		"move_forward",
        "move_backward"
	)

	var direction = (
		camera_pivot.global_basis *
		Vector3(input_dir.x, 0, input_dir.y)
	)

	direction.y = 0
	direction = direction.normalized()

	var current_speed = walk_speed

	if Input.is_action_pressed("sprint"):
		current_speed = sprint_speed

	if direction:
		velocity.x = direction.x * current_speed
		velocity.z = direction.z * current_speed
	else:
		velocity.x = move_toward(velocity.x, 0, current_speed)
		velocity.z = move_toward(velocity.z, 0, current_speed)

	move_and_slide()
